//
//  ViewController.m
//  complexProj
//
//  Created by Владимир on 19/03/2019.
//  Copyright © 2019 Владимир. All rights reserved.
//

#import "ViewController.h"
#import "complexProj-Swift.h"

@interface ViewController ()
- (realSequence *) createRealSequenceObject;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    // SwiftyForObjectiveC *variable = [self createMySwiftObject];
    // NSInteger result = [variable sum];
    // NSLog(@"%ld", result);
    
    realSequence *myVar = [self createRealSequenceObject];
    [myVar fullSeq];
    NSLog(@"%li", (long)[myVar real_Count]);
    NSLog(@"%@", [myVar atI:0]);
    NSLog(@"%@", [myVar atI:1]);
    NSLog(@"%@", [myVar atI:2]);
    [myVar fullSeq];
    NSLog(@"%li", (long)[myVar real_Count]);
    NSLog(@"%@", [myVar atI:4]);
    //[myVar atI:1];

}

- (realSequence *) createRealSequenceObject{
    realSequence * mysq = [realSequence new];
    return mysq;
}

@end
