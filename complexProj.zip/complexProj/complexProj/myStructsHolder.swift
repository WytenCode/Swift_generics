//
//  myStructsHolder.swift
//  complexProj
//
//  Created by Владимир on 19/03/2019.
//  Copyright © 2019 Владимир. All rights reserved.
//

import Foundation

protocol Container{
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int {get}
    subscript(i: Int) -> Item {get}
}

struct mySequence<Element>: Container{
    var items = [Element]()
    mutating func push(_ item:Element){
        items.append(item)
    }
    mutating func pop() -> Element{
        // что стоит сделать: вывести значение первого элемента, сместить все элементы на 1 индекс назад, убрать послденюю пустую ячейку
        //return items.removeLast()
        let res = items[0]
        items = Array(items[1..<self.count])
        return res
    }
    
    mutating func append(_ item: mySequence<Element>.Item) {
        self.push(item)
    }
    
    var count: Int{
        return items.count
    }
    subscript(i: Int) -> Element{
        return items[i]
    }
    
    func printAll(){
        for index in 0..<count{
            print("%@", items[index])
        }
        print("/n")
    }
}

class realSequence: NSObject{
    private var innerSequence = mySequence<String>()
    
    @discardableResult
    @objc func real_Count() -> Int{
        return innerSequence.count
    }
    
    @objc func fullSeq(){
        innerSequence.append("Nick")
        innerSequence.append("Anna")
        innerSequence.append("Suzi")
    }
    
    @discardableResult
    @objc func at(i: Int) -> String{
        return innerSequence[i]
    }
}
