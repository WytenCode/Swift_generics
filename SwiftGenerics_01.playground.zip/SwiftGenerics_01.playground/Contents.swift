import UIKit

// MARK: - Задача 1 "Сделать так, чтобы закомментиррованный код работал"

func sumTwoValues<T : Numeric>(_ a: T, _ b: T) -> T {
	let result = a + b
	return result
}

protocol Container{
    associatedtype Item
    mutating func append(_ item : Item)
    var count : Int {get}
    subscript(i: Int) -> Item {get}
}

extension String:Container{
    
    subscript(i:Int) -> Character{
        return self[index(startIndex, offsetBy: i)]
    }
}

func sumTwoValues<T : Container>(_ a: T, _ b: T) -> T {
    var result = a
    for index in 0..<b.count{
        result.append(b[index])
    }
    return result
}


let a = 25.0
let b = 34.0

let resultDouble = sumTwoValues(a, b)
print(resultDouble)

let c = "ABC"
let d = "DEF"

let resultString = sumTwoValues(c, d)
print(resultString)
