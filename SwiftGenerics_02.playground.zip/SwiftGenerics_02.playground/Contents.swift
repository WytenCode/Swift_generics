import UIKit

// MARK: - Задача 2
protocol Container{
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int {get}
    subscript(i: Int) -> Item {get}
}

class BindElement<T>  {
    let value: T
    public var next: BindElement?
    
    public init(value : T) {
        self.value = value
    }
    
}

struct  BindedList<Element>: Container{
    private var firstItem : BindElement<Element>?
    
    mutating func pop() -> Element?{
        // убираем первый элемент и выводим его
        guard let first = firstItem else { return nil }
        let res = first.value
        firstItem = firstItem?.next
        return res
    }

    mutating func append(_ item: BindedList<Element>.Item) {
        let newBind = BindElement<Element>(value: item)
        newBind.next = firstItem
        firstItem = newBind
    }

    var count: Int{
        var cnt = 0
        if let first = firstItem {
            var current = first
            cnt = cnt + 1
            while current.next != nil
            {
                cnt = cnt + 1
                current = current.next!
            }
        }
        return cnt
    }
    subscript(i: Int) -> Element{
        var cnt = 0
        var current = firstItem
        if let first = firstItem {
            current = first
            while cnt != i
            {
                cnt = cnt + 1
                current = current?.next!
            }
        }
        let res = current!
        return res.value
    }

    func printCount(){
        print(self.count)
    }
}

struct mySequence<Element>: Container{
    var items = [Element]()
    mutating func push(_ item:Element){
        items.append(item)
    }
    mutating func pop() -> Element{
        // что стоит сделать: вывести значение первого элемента, сместить все элементы на 1 индекс назад, убрать послденюю пустую ячейку
        //return items.removeLast()
        let res = items[0]
        items = Array(items[1..<self.count])
        return res
    }
    
    mutating func append(_ item: mySequence<Element>.Item) {
        self.push(item)
    }
    
    var count: Int{
        return items.count
    }
    subscript(i: Int) -> Element{
        return items[i]
    }
    
    func printAll(){
        for index in 0..<count{
            print("%@", items[index])
        }
        print("/n")
    }
}


// running programm
// связанный список
var testStr = BindedList<String>()
testStr.append("Nick")
testStr.append("Anna")
testStr.printCount()
print(testStr[0])
print(testStr[1])

testStr.pop()
testStr.printCount()

var testSequence = mySequence<String>()
testSequence.append("Igor")
testSequence.append("Suzi")
testSequence.append("Nikol")
testSequence.printAll()
print(testSequence.count)
testSequence.pop()
testSequence.printAll()
print(testSequence.count)
testSequence.append("Victoria")
testSequence.printAll()
print(testSequence.count)
testSequence.pop()
testSequence.printAll()
print(testSequence.count)
testSequence.pop()
testSequence.printAll()
print(testSequence.count)
